import { Container } from "react-bootstrap";
import "../Section1/Section.css";

function Section1() {
  return (
    <>
      {/* <Container fluid className="ms-0 me-0"> */}
      <div className="b1">
        <div className="b3">
          <div className="b2">
            <span>
            CURRENT DEALS
515 East 80th
            </span>
          </div>
          <div className="b5 mt-2">
            <p className="b4">
            In the heart of Manhattan, this 126 lot parking garage sits with a commanding view of the surrounding landscape. What's better, with minimal competition in the vicinity, this parking facility promises high occupancy rates and steady revenue streams. Capitalize on the this for your portfolio with us!
            </p>
          </div>
          {/* <div className="b6 mt-3">
            <div className="b7">
              <div className="b8">$10M</div>
              <p>Monthly Limit</p>
            </div>{" "}
            <div className="b7">
              <div className="b8">15.0%</div>
              <p>Preferred Returns</p>
            </div>{" "}
            <div className="b7">
              <div className="b8">$500M</div>
              <p>U.S. Loan Syndicate Size</p>
            </div>
          </div>
          <div className="b5 mt-2">
            <p className="b4a">
              We are now offering reservations for non-U.S investors. To access
              the full investor deck, please fill out the intake form below.
            </p>
          </div> */}
          <div className="b9 mt-2">
            <button className="b10">GET STARTED</button>
          </div>
        </div>
      </div>
      {/* </Container> */}
    </>
  );
}
export default Section1;
