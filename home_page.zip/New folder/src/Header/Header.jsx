import "../Header/Header.css";
import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import Form from "react-bootstrap/Form";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import logo from "../Images/logo.png";

function Header() {
  return (
    <>
      <div className="a3">
        The Chateau App is now live on Arbitrum One. Learn More
      </div>
      <Navbar expand="lg" >
        <Container>
          <Navbar.Brand href="#">
            <img className="logo-image" src={logo} alt="logo" />
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="navbarScroll" style={{background: "#fff"}} />
          <Navbar.Collapse id="navbarScroll">
            <Nav
              className="mx-auto my-2 my-lg-0"
              style={{ maxHeight: "100px" }}
              navbarScroll>
              <Nav.Link className="a2" href="#action1">
                Investor
              </Nav.Link>
              <Nav.Link className="a2" href="#action2">
                Partner
              </Nav.Link>
              <Nav.Link className="a2" href="#action3">
                About
              </Nav.Link>
              <Nav.Link className="a2" href="#action4">
                Community
              </Nav.Link>
            </Nav>
            <Form className="d-flex a4">
              <Button className="a4">Enter App</Button>
            </Form>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </>
  );
}
export default Header;
