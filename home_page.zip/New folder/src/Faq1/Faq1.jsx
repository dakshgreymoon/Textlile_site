import React from "react";
import { Col, Container, Row } from "react-bootstrap";
import "../Faq1/Faq1.css";
import { FiPlus } from "react-icons/fi";
import plusImage from "../Images/plus.svg";  
import crossImage from "../Images/close.svg";

import { useRef, useState, useEffect, useLayoutEffect } from "react";

export default function Faq1() {

  const [name, setName] = useState("");
  const [selectedId, setSelectedId] = useState();
  const [active, setActive] = useState(false);
  const ref = useRef(null);
  // const [icon, setIcon] = useState({a2});

  const data = [
    {
      id: 1001,
      label: "How does Web3 redefine financial growth?",
      detail:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.",
    },
    {
      id: 1002,
      label: "Why is blockchain considered the back bone of the digital revolutionn?",
      detail:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.",
    },
    {
      id: 1003,
      label: "What makes Web3 more than just a tech nological shift?",
      detail:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.",
    },
    {
      id: 1004,
      label: "How does Web3 empower indicviduals in the digital ecosystem ?",
      detail:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.",
    },
    
  ];

  const handleClick = (id) => {
    setSelectedId(id !== selectedId ? id : null);
    // setIcon(id);
  };

  return (
    <>
      <br />
      <br />
      <Container>
        <Row>
          <Col>
            <div className="g1">
              <div className="g2">
                <div className="g3">FAQ</div>
            
                {data.map((val, i) => (
                  <div className="g4"
                    key={i}
                  >
                    <div className="g6"
                      onClick={() => {
                        handleClick(val.id);
                        setActive(!active);
                        setName(val.label);
                      }}
                    >
                      <div className="g5"
                      // className={`${
                      //   selectedId === val.id
                      //     ? styles.activeQuestion
                      //     : styles.inactiveQuestion
                      // } ${styles.cmsFaqQuestion}`}
                      >
                        {val.label}
                      </div>
                      <div>
                        <div className="g7">
                          <img
                           src={selectedId === val.id ? crossImage : plusImage}
                            alt="plusMinus"
                            width="20px"
                          />
                        </div>
                      </div>
                    </div>
                    {selectedId === val.id && (
                      <p className="g8" ref={ref}>
                        {val.detail}
                      </p>

                    )}
                    
                <hr />
                  </div>

                ))}
              </div>
            </div>
            
          </Col>
        </Row>
      </Container>
      <br />
    </>
  );
}



