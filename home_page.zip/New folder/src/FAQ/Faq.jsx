import React from "react";
import { Col, Container, Row } from "react-bootstrap";
import "../FAQ/Faq.css";
import { FaRegCopy } from "react-icons/fa";

export default function Faq() {
  return (
    <>
      <br />
      <Container>
        <Row className=" f12">
          <Col md={12} lg={6} xl={6} xxl={6} className="">
            <div className="f1">
              <div className="f3">
                <div className="f4">CURRENT DEALS</div>
                <div className="f5">515 East 80th</div>
                <hr />
              </div>
            </div>
          </Col>
          <Col md={12} lg={6} xl={6} xxl={6} className="mt-5 p-5 f9">
            <div className="f6 ">
              <div className="f7 mt-5 ms-5">
                <div className="f8">
                  <h1>
                    <FaRegCopy />
                  </h1>
                </div>
                <br />
                <p>
                  In the heart of Manhattan, this 126 lot parking garage sits
                  with a commanding view of the surrounding landscape. What's
                  better, with minimal competition in the vicinity, this parking
                  facility promises high occupancy rates and steady revenue
                  streams. Capitalize on the this for your portfolio with us!
                </p>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
      <center>
        <div className="f10">
          <div className="f11">Get Started</div>
        </div>
      </center>
    </>
  );
}
