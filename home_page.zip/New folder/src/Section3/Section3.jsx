import React from "react";
import { Col, Container, Row } from "react-bootstrap";
import a1 from "../Images/9.svg";
import "../Section3/Section3.css";

export default function Section3() {
  return (
    <>
      <Container className="mt-4">
        <div className="c2">
          <div className="c3">
            <div className="c1">How it Works</div>
            <Row className="mt-5">
              <Col>
                <div className="d2">
                  <div className="d4a">
                    <div className="d4 mb-4">
                      <div className="d6">
                        <div className="d7">We Find Great Deals</div>
                        <div className="d8">
                        We look for real estate assets where the stabilized yield will be high, and there is a significant chance of capital appreciation
                        </div>
                      </div>
                    </div>
                    <div className="d4 mb-4">
                      <div className="d6">
                        <div className="d7">We Partner With Operators</div>
                        <div className="d8">
                        We partner with experienced operators to put a management team in place for the asset
                        </div>
                      </div>
                    </div>{" "}
                    <div className="d4 mb-4">
                      <div className="d6">
                        <div className="d7">We Tokenize The Asset</div>
                        <div className="d8">
                        We tokenize the asset, say a parking garage, so investors can buy and transfer their stake on-chain
                        </div>
                      </div>
                    </div>{" "}
                    <div className="d4 mb-4">
                      <div className="d6">
                        <div className="d7">You Invest Painlessly</div>
                        <div className="d8">
                        You get exposure to a great asset in a fantastic asset class that has historically outperformed the S&P500 - without lifting a finger
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* <img src={a1} alt="sfd" className="d1" /> */}
                </div>
              </Col>
            </Row>
          </div>
        </div>
      </Container>
    </>
  );
}
